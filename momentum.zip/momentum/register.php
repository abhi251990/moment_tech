<?php 
    //getting urls
  $base_url="https://".$_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"].'?').'/';
    session_start(); 
   if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true){
      
        header("location:".$base_url); 
        exit(); 
    }
    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register']))
    {
    
    extract($_POST); 
    
    //validating all fields is filled
    
    if( (!isset($fname)) || $fname=="") {
        $msg = "Name is Required*";
    }else if(!isset($username) ||  $username=="" ){
         $msg = 'Username is Required*'; 
    }
    else if(!isset($email) ||  $email==""){
        $msg = "Email is Required*"; 
    }
    else if(!isset($pass) ||  $pass==""){
        $msg = "Password is Required*"; 
    }else{
        //matching pass
        if($cpass == $pass){
            //sending user data to api
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "https://momentumtechnology.com.au/api/userplus/register/");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, true);
            $data = array(
                'key' => '5bf524272d4af',
                'username' => $username,
                'display_name' =>$fname ,
                'email'=>$email,
                'user_pass'=> $pass
            );
            
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            $output = curl_exec($ch);
            $info = curl_getinfo($ch);
            curl_close($ch);
            
            $resp_obj =  json_decode($output);  
            if($resp_obj->status == 'ok'){
                echo "<script>alert('You Are Registered Now !'); window.location='".$base_url."login.php'; </script>"; 
                
            }else{
                $msg =  $resp_obj->error; 
            }
        }else{
            $msg = 'Passwords Should be Match*'; 
        }
        
    }
        
    
    }
?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from wrappixel.com/demos/admin-templates/material-pro/horizontal/pages-register2.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 20 Nov 2018 13:34:31 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo $base_url ;?>assets/images/fevicon.ico">
    <title>Momentum Technology >> Secure Portal</title>
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo  $base_url ;?>assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
	<link href="css/custom.css" rel="stylesheet">
    <!-- You can change the theme colors from here -->
    <link href="css/colors/blue.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style>
    #message {
        display:none;
        background: #f1f1f1;
        color: #000;
        position: relative;
        padding: 20px;
        margin-top: 10px;
    }
    
    #message p {
        padding: 0px 35px;
        margin:0px auto 5px 0px;
        font-size: 14px;
    }
    
    /* Add a green text color and a checkmark when the requirements are right */
    .valid {
        color: green;
    }
    
    .valid:before {
        position: relative;
        left: -20px;
        content: "✔";
    }
    
    /* Add a red text color and an "x" when the requirements are wrong */
    .invalid {
        color: red;
    }
    
    .invalid:before {
        position: relative;
        left: -20px;
        content: "✖";
    }
</style>
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <section id="wrapper" class="login-register login-sidebar"  style="background-image:url(<?php echo $base_url ;?>assets/images/background/login-register.jpg);">
  <div class="login-box card">
    <div class="card-body">
      <form class="form-horizontal form-material" method="post" id="loginform" action="">
          
        <a href="javascript:void(0)" class="text-center db"><img class="logo_login_reg" src="<?php echo $base_url ;?>assets/images/momentum_logo.png" alt="Home" /></a> 
        <h3 class="box-title m-t-40 m-b-0">Register Now</h3><small>Create your account and enjoy</small> 
        <div class="form-group m-t-20">
          <div class="col-xs-12">
            <input class="form-control" name="fname" type="text" required="" placeholder="Full Name">
          </div>
        </div>
      
        <div class="form-group ">
          <div class="col-xs-12">
            <input class="form-control" name="username" type="text" required="" placeholder="username">
          </div>
        </div>
        <div class="form-group ">
          <div class="col-xs-12">
            <input class="form-control" name="email" type="email" required="" placeholder="email">
          </div>
        </div>
        <div class="form-group ">
          <div class="col-xs-12">
              <input type="password" id="psw" class="form-control" name="pass" placeholder="Create Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
            
          </div>
        </div>
        <div class="form-group">
          <div class="col-xs-12">
                <input class="form-control" type="password" name="cpass" required placeholder="Confirm Password">
          </div>
        </div>
       
         <p style="color:red"><?php echo $msg ; ?></p>
        <div class="form-group text-center m-t-20">
          <div class="col-xs-12">
            <button name="register" class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Sign Up</button>
         </div>
        </div>
       
        <div class="form-group m-b-0">
          <div class="col-sm-12 text-center">
            Already have an account? <a href="<?php echo $base_url ; ?>login.php" class="text-info m-l-5"><b>Sign In</b></a>
          </div>
        </div>
        <div id="message">
          <h5>Password must contain the following:</h5>
          <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
          <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
          <p id="number" class="invalid">A <b>number</b></p>
          <p id="length" class="invalid">Minimum <b>8 characters</b></p>
        </div>
      </form>
      
    </div>
  </div>
</section>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?php echo  $base_url ;?>assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo  $base_url ;?>assets/plugins/popper/popper.min.js"></script>
    <script src="<?php echo  $base_url ;?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="<?php echo  $base_url ;?>assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="<?php echo  $base_url ;?>assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="js/custom.min.js"></script>
    <!-- ============================================================== -->
    <!-- Style switcher -->
    <!-- ============================================================== -->
    <script src="<?php echo $base_url ;?>assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
    <script>
var myInput = document.getElementById("psw");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
    document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
    document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>
</body>


<!-- Mirrored from wrappixel.com/demos/admin-templates/material-pro/horizontal/pages-register2.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 20 Nov 2018 13:34:31 GMT -->
</html>

