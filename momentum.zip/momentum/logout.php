<?php 

$base_url="https://".$_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"].'?').'/';
session_start();
$_SESSION['loggedin'] = false; 
$_SESSION['user_id'] = "";
$_SESSION['username'] = ""; 
$_SESSION['user_info']= ""; 
header("location:".$base_url."login.php"); 


?>